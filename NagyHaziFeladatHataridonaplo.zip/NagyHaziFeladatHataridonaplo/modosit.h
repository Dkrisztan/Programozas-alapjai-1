#ifndef MODOSIT_H
#define MODOSIT_H

void modmenuop();
void modmenu(char *s);
Rekord fileertek(char *s);

#endif
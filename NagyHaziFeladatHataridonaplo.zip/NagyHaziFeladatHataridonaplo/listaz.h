#ifndef LISTAZ_H
#define LISTAZ_H

char *reszsztring(char const *eredeti, int mettol, int meddig);
void kilistaz(char *s);
void honap(char *s);
void nap(char *s);
void het(char *s);
int hetnap(int d, int m, int y);

#endif
#ifndef FOLDER_H
#define FOLDER_H

void fajlkilistaz();

#endif
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>
#include "debugmalloc.h"
#include "fuggvenyek.h"


SzoLista *ujegyszavas(char const *szo) {
  SzoLista *uj;
  uj = (SzoLista*) malloc(sizeof(SzoLista));
  uj->kov = NULL;
  uj->szo = (char*) malloc(sizeof(char)*(strlen(szo)+1));
  strcpy(uj->szo, szo);

  return uj;
}

SzoLista *keres(SzoLista *l, char *mit) {
  SzoLista *p;
  for (p=l; p!=NULL; p=p->kov) {
    if (strcmp(p->szo,mit) == 0) {
      return p;
    }
  }
  return NULL;
}

void lista_free(SzoLista *l) {
  SzoLista *p=l;

  while (p!=NULL) {
    SzoLista *tmp = p->kov;
    free(p);
    p=tmp;
  }
}

void EsemenyKeres(char *s) {

  SzoLista *lista, *tal;
  FILE *fp;

  DIR *folder;
  struct dirent *entry;
  int files = 0;
  folder = opendir("rekordok");
  if(folder == NULL)
  {
    perror("Nem lehet a foldert olvasni");
    exit(0);
  }
  while( (entry=readdir(folder)) ){
    files++;
    if(strcmp(entry->d_name,".") != 0 && strcmp(entry->d_name,"..") != 0) {
      lista = ujegyszavas(entry->d_name);
      //fflush(stdin);
      //s = dintext();
      tal = keres(lista, s);
      if (tal != NULL) {
        while(true) {
          printf(" ** Van ilyen talalat: %s **\n", tal->szo);

          char seged[] = "rekordok/";
          char nev[500];
          char helyszin[500];
          char megjegyzes[500];
          char datum[20];
          int ora, perc;

          strcat(seged,tal->szo);

          fp = fopen(seged, "r");

          fscanf(fp,"%s\n", nev);
          fscanf(fp,"%s\n", helyszin);
          fscanf(fp,"%s\n", megjegyzes);
          fscanf(fp,"%s\n", datum);
          fscanf(fp,"%d:", &ora);
          fscanf(fp,"%d", &perc);
          printf("Az esemeny neve: %s\n", nev);
          printf("Az esemeny helyszine: %s\n", helyszin);
          printf("Az esemeny megjegyzese: %s\n", megjegyzes);
          printf("Az esemeny datuma: %s\n", datum);
          printf("Az esemeny pontos ideje: %d:%d\n", ora, perc);
          printf("\nNyomd meg az Enter-t a tovabblepeshez");
          if (getchar() == '\n') {
            system("cls");
            menu();
          }
          lista_free(lista);
          lista_free(tal);
          fclose(fp);
        }
      }
    }
  }
  closedir(folder);
}
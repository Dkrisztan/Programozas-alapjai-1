#ifndef FUGGVENYEK_H
#define FUGGVENYEK_H

typedef struct Rekord {
  char *nev; //TODO dinamikusan legyen foglalva
  char *helyszin; //TODO dinamikusan legyen foglalva
  char *megjegyzes; //TODO dinamikusan legyen foglalva
  char *datum;  //TODO dinamikusan legyen foglalva
  int ora, perc;
} Rekord;

typedef struct SzoLista {
  char *szo;
  struct SzoLista *kov;
} SzoLista;

void menuopciok();
void menu();
void newFile(char *s);
char *dintext();
void esemenyFeltolt(char *s);
void RekordFree(Rekord r);
void fajlkilistaz();
void torol(char *s);
SzoLista *ujegyszavas(char const *szo);
SzoLista *keres(SzoLista *l, char *mit);
void lista_free(SzoLista *l);
void EsemenyKeres(char *s);


#endif
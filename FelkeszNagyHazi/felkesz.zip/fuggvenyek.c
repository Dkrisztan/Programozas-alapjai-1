#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>
#include "debugmalloc.h"
#include "fuggvenyek.h"


void RekordFree(Rekord r) {
  //free(r.nev);
  free(r.helyszin);
  free(r.megjegyzes);
  free(r.datum);
}

//TODO dinamikus tomb foglalo stringeknek
char *dintext() {
  int db = 0;
  char *sor = (char*) malloc(sizeof(char) * 1);
  sor[0] = '\0';
  char ujkar;
  while (scanf("%c", &ujkar) == 1 && ujkar != '\n') {
    char *ujtomb = (char*) malloc(sizeof(char) * (db+1+1));
    for (int i = 0; i < db; ++i) {
      ujtomb[i] = sor[i];
    }
    free(sor);
    sor = ujtomb;
    ujtomb[db] = ujkar;     
    ujtomb[db+1] = '\0';
    ++db;
  }
  return sor;
}

void newFile(char *s) {
  char seged[] = "rekordok/";
  strcat(seged,s);
  FILE *fp;
  fp  = fopen(seged, "w+");
  fclose(fp);
}

void esemenyFeltolt(char *s) {
  char seged[] = "rekordok/";
  Rekord r;
  FILE *fp;
  strcat(seged,s);
  fp  = fopen(seged, "w+");

  fflush(stdin);

  //! Nev feltoltese
  //printf("Add meg az esemeny nevet: ");
  strcpy(r.nev,s);
  fprintf(fp,"%s\n",r.nev);

  //! Helyszin feltoltese
  printf("Add meg az esemeny helyszinet: ");
  r.helyszin = dintext();
  fprintf(fp,"%s\n",r.helyszin);

  //! Megjegyzes feltoltese
  printf("Adj meg egy megjegyzest: ");
  r.megjegyzes = dintext();
  fprintf(fp,"%s\n",r.megjegyzes);

  //! Datum feltoltese
  printf("Adj meg egy datumot [yyyy-mm-dd] : ");
  r.datum = dintext();
  fprintf(fp,"%s\n",r.datum);

  //! Ido feltoltese
  int ora, perc;
  printf("Add meg a pontos idejet az esemenynek : -vel elvalasztva: ");
  scanf("%d:%d",&ora,&perc);
  r.ora = ora;
  r.perc = perc;
  fprintf(fp,"%d:",ora);
  fprintf(fp,"%d",perc);
  
  fclose(fp);
  RekordFree(r); //* felszabaditjuk a struktura osszes dinamikusan foglalt tombjet
  
  printf("** Esemeny sikeresen letrehozva! **");
  fflush(stdout);
  system("cls");
  menu();
}

void torol(char *s) {
  char seged[] = "rekordok/";
  strcat(seged,s);
  if (remove(seged) == 0) {
        printf(" ** Sikeresen toroltuk a rekordot. ** ");
    } else {
        printf(" ** A rekordot nem sikerult torolni. ** ");
    }
  sleep(3);
}

void menuopciok() {
  printf("[1] Uj rekord letrehozasa\n");
  printf("[2] Rekord modositasa\n");
  printf("[3] Rekord torlese\n");
  printf("[4] Esemenyek idorendi kilistazasa\n");
  printf("[5] Esemeny keresese\n");
  printf("[6] Osszes esemeny kilistazasa\n");
  printf("[0] Kilepes a programbol\n");
  printf("Add meg a valasztasod egy fenti szammal: ");
}

void menu() {
  menuopciok();
  int valasztas;
  fflush(stdin);
  scanf("%d", &valasztas);
  if(valasztas >= 0 && valasztas <= 6)
  {
    switch(valasztas) {
      case 1:
        //* Uj rekord letrehozasa
        fflush(stdin);
        printf("Add meg az esemeny nevet: ");
        char *s = dintext();
        newFile(s);
        //! program megszakad futni ?fflush?
        esemenyFeltolt(s);
        free(s);
        //! Meghivodik rekurzivan a menu() fuggveny
        break;

      case 2:
        printf("Modositunk egy rekordot\n");
        break;

      case 3:
        fflush(stdin);
        printf("Add meg a torlendo esemeny nevet: ");
        char *x = dintext();
        torol(x);
        fflush(stdin);
        free(x);
        break;

      case 4:
        printf("Esemenyeket listazunk ki\n");
        break;

      case 5:
        printf("Add meg a keresendo esemeny nevet: ");
        char *keres;
        fflush(stdin);
        keres = dintext();
        EsemenyKeres(keres);
        sleep(5);
        free(keres);
        system("cls");
        menu();
        break;

      case 6:
        fflush(stdin);
        while(true) {
          fajlkilistaz();
          printf("Nyomd meg az Enter-t a tovabblepeshez");
          if (getchar() == '\n') {
            break;
          }
        }
        system("cls");
        menu();

      case 0: 
        exit(0);

      default: 
        printf("Rossz valasztas\n");
    }
  } else {
    printf("Rossz valasztas! Probald ujra!\n");
    sleep(2);
    system("cls");
    menu();
  }
}
